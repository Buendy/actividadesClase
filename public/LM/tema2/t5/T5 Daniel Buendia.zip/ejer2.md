
# Curriculum Vitae de Bruce Wayne
## Datos personales
* Nombre completo: __Bruce Wayne__
* Fecha de nacimiento: __1/5/1939__
* Lugar de nacimiento: __Gotham City__

## Formación académica
* 1956-1961: __Universidad del Espantapájaros__
* 1952-1956: __Instituto de Dos Caras__
* 1944-1952: __Escuela Primaria del Joker__

## Experiencia laboral
* 1975-1985: __En el paro__
* 1965-1975: __Cazavillanos y demás chusma__
* 1962-1965: __Aprendiz de superhéroe__

