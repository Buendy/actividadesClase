# HTML

__HTML__ son las siglas de *HyperText Markup Language*, que puede traducirse como lenguaje de marcas o marcado de hipertexto.
El lenguaje __HTML__ se emplea para crear las páginas web. Es muy fácil ver el código __HTML__ de una página web, la opción exacta cambia de un navegador a otro y también puede cambiar de una versión a otra de un mismo navegador, pero suelen tener un nombre similar.
## Historia del HTML
Los inicios del lenguaje __HTML__ se remontan al año 1990, cuando *Tim Berners-Lee* creó la primera página web.
## Versiones de HTML
*Tim Berners-Lee* definió la primera versión de __HTML__ en el año 1991.

En la actualidad, la última versión de __HTML__ es HTML5
